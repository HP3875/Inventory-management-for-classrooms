﻿// Name: Harsh Patel
// student Number: 8913372

namespace WinFormsApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        private void InitializeComponent()
        {
            AddButton = new Button();
            UpdateButton = new Button();
            ResetButton = new Button();
            ExitButton = new Button();
            ShowRoomsButton = new Button();
            RoomIdLabel = new Label();
            RoomNumberLabel = new Label();
            CapacityLabel = new Label();
            ProjectorsLabel = new Label();
            SmartBoardLabel = new Label();
            AccessibleLabel = new Label();
            MessageLabel = new Label();
            RoomIdTextBox = new TextBox();
            RoomNumberTextBox = new TextBox();
            CapacityTextBox = new TextBox();
            ProjectorsTextBox = new TextBox();
            SmartBoardCheckBox = new CheckBox();
            AccessibleCheckBox = new CheckBox();
            ClassroomListBox = new ListBox();
            WaterlooRadioButton = new RadioButton();
            DoonRadioButton = new RadioButton();
            CambridgeRadioButton = new RadioButton();
            GroupBoxCampus = new GroupBox();
            label1 = new Label();
            GroupBoxCampus.SuspendLayout();
            SuspendLayout();
            // 
            // AddButton
            // 
            AddButton.Location = new Point(515, 15);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(151, 27);
            AddButton.TabIndex = 0;
            AddButton.Text = "Add New Room";
            AddButton.UseVisualStyleBackColor = true;
            AddButton.Click += AddButton_Click;
            // 
            // UpdateButton
            // 
            UpdateButton.Location = new Point(515, 48);
            UpdateButton.Name = "UpdateButton";
            UpdateButton.Size = new Size(151, 27);
            UpdateButton.TabIndex = 1;
            UpdateButton.Text = "Update Room";
            UpdateButton.UseVisualStyleBackColor = true;
            UpdateButton.Click += UpdateButton_Click;
            // 
            // ResetButton
            // 
            ResetButton.Location = new Point(515, 81);
            ResetButton.Name = "ResetButton";
            ResetButton.Size = new Size(151, 27);
            ResetButton.TabIndex = 2;
            ResetButton.Text = "Reset for Next";
            ResetButton.UseVisualStyleBackColor = true;
            ResetButton.Click += ResetButton_Click;
            // 
            // ExitButton
            // 
            ExitButton.Location = new Point(515, 114);
            ExitButton.Name = "ExitButton";
            ExitButton.Size = new Size(151, 25);
            ExitButton.TabIndex = 3;
            ExitButton.Text = "Exit";
            ExitButton.UseVisualStyleBackColor = true;
            ExitButton.Click += ExitButton_Click;
            // 
            // ShowRoomsButton
            // 
            ShowRoomsButton.Location = new Point(12, 274);
            ShowRoomsButton.Name = "ShowRoomsButton";
            ShowRoomsButton.Size = new Size(110, 49);
            ShowRoomsButton.TabIndex = 4;
            ShowRoomsButton.Text = "Show Rooms";
            ShowRoomsButton.UseVisualStyleBackColor = true;
            ShowRoomsButton.Click += ShowRoomsButton_Click;
            // 
            // RoomIdLabel
            // 
            RoomIdLabel.AutoSize = true;
            RoomIdLabel.Location = new Point(12, 15);
            RoomIdLabel.Name = "RoomIdLabel";
            RoomIdLabel.Size = new Size(71, 20);
            RoomIdLabel.TabIndex = 5;
            RoomIdLabel.Text = "Room ID:";
            // 
            // RoomNumberLabel
            // 
            RoomNumberLabel.AutoSize = true;
            RoomNumberLabel.Location = new Point(12, 45);
            RoomNumberLabel.Name = "RoomNumberLabel";
            RoomNumberLabel.Size = new Size(110, 20);
            RoomNumberLabel.TabIndex = 6;
            RoomNumberLabel.Text = "Room Number:";
            // 
            // CapacityLabel
            // 
            CapacityLabel.AutoSize = true;
            CapacityLabel.Location = new Point(12, 79);
            CapacityLabel.Name = "CapacityLabel";
            CapacityLabel.Size = new Size(69, 20);
            CapacityLabel.TabIndex = 7;
            CapacityLabel.Text = "Capacity:";
            // 
            // ProjectorsLabel
            // 
            ProjectorsLabel.AutoSize = true;
            ProjectorsLabel.Location = new Point(12, 116);
            ProjectorsLabel.Name = "ProjectorsLabel";
            ProjectorsLabel.Size = new Size(87, 20);
            ProjectorsLabel.TabIndex = 8;
            ProjectorsLabel.Text = "#Projectors:";
            // 
            // SmartBoardLabel
            // 
            SmartBoardLabel.AutoSize = true;
            SmartBoardLabel.Location = new Point(3, 181);
            SmartBoardLabel.Name = "SmartBoardLabel";
            SmartBoardLabel.Size = new Size(138, 20);
            SmartBoardLabel.TabIndex = 9;
            SmartBoardLabel.Text = "Has Smart Boards ?";
            // 
            // AccessibleLabel
            // 
            AccessibleLabel.AutoSize = true;
            AccessibleLabel.Location = new Point(281, 178);
            AccessibleLabel.Name = "AccessibleLabel";
            AccessibleLabel.Size = new Size(101, 20);
            AccessibleLabel.TabIndex = 10;
            AccessibleLabel.Text = "Is accessible ?";
            // 
            // MessageLabel
            // 
            MessageLabel.AutoSize = true;
            MessageLabel.Location = new Point(12, 220);
            MessageLabel.Name = "MessageLabel";
            MessageLabel.Size = new Size(0, 20);
            MessageLabel.TabIndex = 11;
            // 
            // RoomIdTextBox
            // 
            RoomIdTextBox.Location = new Point(128, 9);
            RoomIdTextBox.Name = "RoomIdTextBox";
            RoomIdTextBox.Size = new Size(178, 27);
            RoomIdTextBox.TabIndex = 12;
            // 
            // RoomNumberTextBox
            // 
            RoomNumberTextBox.Location = new Point(128, 42);
            RoomNumberTextBox.Name = "RoomNumberTextBox";
            RoomNumberTextBox.Size = new Size(178, 27);
            RoomNumberTextBox.TabIndex = 13;
            // 
            // CapacityTextBox
            // 
            CapacityTextBox.Location = new Point(128, 72);
            CapacityTextBox.Name = "CapacityTextBox";
            CapacityTextBox.Size = new Size(178, 27);
            CapacityTextBox.TabIndex = 14;
            // 
            // ProjectorsTextBox
            // 
            ProjectorsTextBox.Location = new Point(128, 109);
            ProjectorsTextBox.Name = "ProjectorsTextBox";
            ProjectorsTextBox.Size = new Size(178, 27);
            ProjectorsTextBox.TabIndex = 15;
            // 
            // SmartBoardCheckBox
            // 
            SmartBoardCheckBox.AutoSize = true;
            SmartBoardCheckBox.Location = new Point(156, 184);
            SmartBoardCheckBox.Name = "SmartBoardCheckBox";
            SmartBoardCheckBox.Size = new Size(18, 17);
            SmartBoardCheckBox.TabIndex = 16;
            SmartBoardCheckBox.UseVisualStyleBackColor = true;
            // 
            // AccessibleCheckBox
            // 
            AccessibleCheckBox.AutoSize = true;
            AccessibleCheckBox.Location = new Point(388, 181);
            AccessibleCheckBox.Name = "AccessibleCheckBox";
            AccessibleCheckBox.Size = new Size(18, 17);
            AccessibleCheckBox.TabIndex = 17;
            AccessibleCheckBox.UseVisualStyleBackColor = true;
            // 
            // ClassroomListBox
            // 
            ClassroomListBox.FormattingEnabled = true;
            ClassroomListBox.Location = new Point(12, 343);
            ClassroomListBox.Name = "ClassroomListBox";
            ClassroomListBox.Size = new Size(829, 184);
            ClassroomListBox.TabIndex = 18;
            // 
            // WaterlooRadioButton
            // 
            WaterlooRadioButton.AutoSize = true;
            WaterlooRadioButton.Location = new Point(6, 19);
            WaterlooRadioButton.Name = "WaterlooRadioButton";
            WaterlooRadioButton.Size = new Size(91, 24);
            WaterlooRadioButton.TabIndex = 19;
            WaterlooRadioButton.TabStop = true;
            WaterlooRadioButton.Text = "Waterloo";
            WaterlooRadioButton.UseVisualStyleBackColor = true;
            // 
            // DoonRadioButton
            // 
            DoonRadioButton.AutoSize = true;
            DoonRadioButton.Location = new Point(132, 19);
            DoonRadioButton.Name = "DoonRadioButton";
            DoonRadioButton.Size = new Size(67, 24);
            DoonRadioButton.TabIndex = 20;
            DoonRadioButton.TabStop = true;
            DoonRadioButton.Text = "Doon";
            DoonRadioButton.UseVisualStyleBackColor = true;
            // 
            // CambridgeRadioButton
            // 
            CambridgeRadioButton.AutoSize = true;
            CambridgeRadioButton.Location = new Point(229, 19);
            CambridgeRadioButton.Name = "CambridgeRadioButton";
            CambridgeRadioButton.Size = new Size(104, 24);
            CambridgeRadioButton.TabIndex = 21;
            CambridgeRadioButton.TabStop = true;
            CambridgeRadioButton.Text = "Cambridge";
            CambridgeRadioButton.UseVisualStyleBackColor = true;
            // 
            // GroupBoxCampus
            // 
            GroupBoxCampus.Controls.Add(WaterlooRadioButton);
            GroupBoxCampus.Controls.Add(DoonRadioButton);
            GroupBoxCampus.Controls.Add(CambridgeRadioButton);
            GroupBoxCampus.Location = new Point(128, 265);
            GroupBoxCampus.Name = "GroupBoxCampus";
            GroupBoxCampus.Size = new Size(406, 58);
            GroupBoxCampus.TabIndex = 22;
            GroupBoxCampus.TabStop = false;
            GroupBoxCampus.Text = "Campus";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 422);
            label1.Name = "label1";
            label1.Size = new Size(0, 20);
            label1.TabIndex = 23;
            label1.Click += label1_Click;
            // 
            // MainForm
            // 
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(854, 539);
            Controls.Add(label1);
            Controls.Add(GroupBoxCampus);
            Controls.Add(ClassroomListBox);
            Controls.Add(AccessibleCheckBox);
            Controls.Add(SmartBoardCheckBox);
            Controls.Add(ProjectorsTextBox);
            Controls.Add(CapacityTextBox);
            Controls.Add(RoomNumberTextBox);
            Controls.Add(RoomIdTextBox);
            Controls.Add(MessageLabel);
            Controls.Add(AccessibleLabel);
            Controls.Add(SmartBoardLabel);
            Controls.Add(ProjectorsLabel);
            Controls.Add(CapacityLabel);
            Controls.Add(RoomNumberLabel);
            Controls.Add(RoomIdLabel);
            Controls.Add(ShowRoomsButton);
            Controls.Add(ExitButton);
            Controls.Add(ResetButton);
            Controls.Add(UpdateButton);
            Controls.Add(AddButton);
            Name = "MainForm";
            Text = "Conestoga Class Room Inventory - Harsh Patel (8913372)";
            GroupBoxCampus.ResumeLayout(false);
            GroupBoxCampus.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Button UpdateButton;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ShowRoomsButton;
        private System.Windows.Forms.Label RoomIdLabel;
        private System.Windows.Forms.Label RoomNumberLabel;
        private System.Windows.Forms.Label CapacityLabel;
        private System.Windows.Forms.Label ProjectorsLabel;
        private System.Windows.Forms.Label SmartBoardLabel;
        private System.Windows.Forms.Label AccessibleLabel;
        private System.Windows.Forms.Label MessageLabel;
        private System.Windows.Forms.TextBox RoomIdTextBox;
        private System.Windows.Forms.TextBox RoomNumberTextBox;
        private System.Windows.Forms.TextBox CapacityTextBox;
        private System.Windows.Forms.TextBox ProjectorsTextBox;
        private System.Windows.Forms.CheckBox SmartBoardCheckBox;
        private System.Windows.Forms.CheckBox AccessibleCheckBox;
        private System.Windows.Forms.ListBox ClassroomListBox;
        private System.Windows.Forms.RadioButton WaterlooRadioButton;
        private System.Windows.Forms.RadioButton DoonRadioButton;
        private System.Windows.Forms.RadioButton CambridgeRadioButton;
        private System.Windows.Forms.GroupBox GroupBoxCampus;
        private Label label1;
    }
}
