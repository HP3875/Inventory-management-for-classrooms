// Harsh Patel 
// Student Number: 8913372

using System;
using System.Windows.Forms;
using WinFormsApp; 
namespace ClassroomInventoryApp
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
