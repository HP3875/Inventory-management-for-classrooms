﻿// Name:Harsh Patel 
// Student Number: 8913372

using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Rooms; 
namespace WinFormsApp
{
    public partial class MainForm : Form
    {
        private readonly ClassroomManager classroomManager;

        public MainForm()
        {
            InitializeComponent();
            classroomManager = new ClassroomManager();
            RoomIdTextBox.Text = classroomManager.GetNextClassroomId().ToString();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            var validationErrors = ValidateClassroomInputs();
            if (validationErrors.Count > 0)
            {
                MessageLabel.ForeColor = System.Drawing.Color.Red;
                MessageLabel.Text = string.Join(Environment.NewLine, validationErrors);
                return;
            }

            var classroom = CreateClassroomFromInputs();
            classroomManager.AddClassroom(classroom);
            MessageLabel.ForeColor = System.Drawing.Color.Blue;
            MessageLabel.Text = "Classroom added successfully!";
            ResetFields();
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            var validationErrors = ValidateClassroomInputs();
            if (validationErrors.Count > 0)
            {
                MessageLabel.ForeColor = System.Drawing.Color.Red;
                MessageLabel.Text = string.Join(Environment.NewLine, validationErrors);
                return;
            }

            var classroom = CreateClassroomFromInputs();
            classroomManager.UpdateClassroom(classroom);
            MessageLabel.ForeColor = System.Drawing.Color.Blue;
            MessageLabel.Text = "Classroom updated successfully!";
            ResetFields();
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            ResetFields();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowRoomsButton_Click(object sender, EventArgs e)
        {
            var classrooms = classroomManager.GetAllClassrooms();

            // Remove Campus filter logic if not available
            // Assuming no Campus property, so removing campus filtering
            // if (WaterlooRadioButton.Checked)
            //     classrooms = classrooms.Where(c => c.Campus == "Waterloo").ToList();
            // else if (DoonRadioButton.Checked)
            //     classrooms = classrooms.Where(c => c.Campus == "Doon").ToList();
            // else if (CambridgeRadioButton.Checked)
            //     classrooms = classrooms.Where(c => c.Campus == "Cambridge").ToList();

            ClassroomListBox.Items.Clear();
            foreach (var classroom in classrooms)
            {
                ClassroomListBox.Items.Add(classroom.ToString());
            }
        }

        private List<string> ValidateClassroomInputs()
        {
            var errors = new List<string>();

            if (!int.TryParse(RoomIdTextBox.Text, out var roomId) || roomId <= 0)
                errors.Add("Invalid Room ID. It must be a positive integer.");

            if (string.IsNullOrWhiteSpace(RoomNumberTextBox.Text))
                errors.Add("Room Number is required.");

            if (!int.TryParse(CapacityTextBox.Text, out var capacity) || capacity <= 0)
                errors.Add("Capacity must be a positive integer.");

            if (!int.TryParse(ProjectorsTextBox.Text, out var projectors) || projectors < 0)
                errors.Add("Number of Projectors must be a non-negative integer.");

            

            return errors;
        }

        private Classroom CreateClassroomFromInputs()
        {
            var roomId = int.Parse(RoomIdTextBox.Text);
            var roomNumber = RoomNumberTextBox.Text.ToUpper();
            var capacity = int.Parse(CapacityTextBox.Text);
            var projectors = int.Parse(ProjectorsTextBox.Text);
            var smartBoard = SmartBoardCheckBox.Checked;
            var accessible = AccessibleCheckBox.Checked;

            
            return new Classroom
            {
                ClassroomId = roomId,
                RoomNumber = roomNumber,
                Capacity = capacity,
                NumberOfProjectors = projectors,
                IncludesSmartBoard = smartBoard,
                IsAccessible = accessible
                
            };
        }

        private void ResetFields()
        {
            RoomIdTextBox.Text = classroomManager.GetNextClassroomId().ToString();
            RoomNumberTextBox.Clear();
            CapacityTextBox.Clear();
            ProjectorsTextBox.Clear();
            SmartBoardCheckBox.Checked = false;
            AccessibleCheckBox.Checked = false;
            MessageLabel.Text = "";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
