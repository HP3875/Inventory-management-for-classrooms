﻿// Name: Harsh Patel 
// Student Number: 8913372
using System;

namespace Rooms
{
    [Serializable]
    public class Classroom
    {
        public int ClassroomId { get; set; }
        public string RoomNumber { get; set; } = string.Empty; 
        public int Capacity { get; set; }
        public int NumberOfProjectors { get; set; }
        public bool IncludesSmartBoard { get; set; }
        public bool IsAccessible { get; set; }

        public override string ToString()
        {
            return $"ID: {ClassroomId}, Number: {RoomNumber}, Capacity: {Capacity}, Projectors: {NumberOfProjectors}, SmartBoard: {IncludesSmartBoard}, Accessible: {IsAccessible}";
        }
    }
}
