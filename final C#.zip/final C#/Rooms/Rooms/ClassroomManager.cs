﻿// Name: Harsh Patel 
// Student Number: 8913372

using System.Collections.Generic;
using System.Linq;

namespace Rooms
{
    public class ClassroomManager
    {
        private readonly List<Classroom> classrooms = new(); 
        private int nextId;

        public ClassroomManager()
        {
            nextId = 1;
        }

        public void AddClassroom(Classroom classroom)
        {
            classroom.ClassroomId = nextId++;
            classrooms.Add(classroom);
        }


        public void UpdateClassroom(Classroom updatedClassroom)
        {
            var existingClassroom = classrooms.SingleOrDefault(c => c.ClassroomId == updatedClassroom.ClassroomId);
            if (existingClassroom != null)
            {
                existingClassroom.RoomNumber = updatedClassroom.RoomNumber;
                existingClassroom.Capacity = updatedClassroom.Capacity;
                existingClassroom.NumberOfProjectors = updatedClassroom.NumberOfProjectors;
                existingClassroom.IncludesSmartBoard = updatedClassroom.IncludesSmartBoard;
                existingClassroom.IsAccessible = updatedClassroom.IsAccessible;
            }
        }

        public List<Classroom> GetAllClassrooms()
        {
            return classrooms;
        }

        public int GetNextClassroomId()
        {
            return nextId;
        }
    }
}
